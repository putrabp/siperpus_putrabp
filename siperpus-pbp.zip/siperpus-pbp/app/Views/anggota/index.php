<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h1>Manajemen Anggota</h1>

<p>
Data anggota perpustakaan akan dikelola
melalui halaman ini.
</p>
<div class="cards">

    <div class="card">
        <h3>Total Anggota</h3>

        <p>
            <?= esc((string) $total_Anggota) ?>
        </p>
    </div>

</div>

<?= $this->endSection() ?>