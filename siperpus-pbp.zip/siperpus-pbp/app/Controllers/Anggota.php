<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Anggota extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Anggota',
            'judulHalaman' => 'Manajemen Anggota',
            'total_Anggota' => 75
        ]; 
            return view('anggota/index', $data
        );
        //
    }
}
