<?php

namespace App\Controllers;

use App\Models\BookModel;
use CodeIgniter\HTTP\ResponseInterface;

class Buku extends BaseController
{
    public function index()
    {   $bookModel = new BookModel();

        $books = $bookModel
            ->orderBy('title', 'ASC')
            ->findAll();


        $data = [
            'title' => 'Data Buku',
            'books' => $books,
            'totalBooks' => count($books),
        ];
            return view('buku/index', $data);
        //
    }
}
